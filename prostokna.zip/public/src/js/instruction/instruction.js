if ($('#instruction').length) {
    console.log('instruction')
}