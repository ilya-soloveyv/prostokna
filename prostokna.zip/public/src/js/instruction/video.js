if ($('#instruction_video').length) {
    console.log('instruction_video')
}