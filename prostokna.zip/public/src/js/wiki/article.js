if ($('#wiki_article').length) {

}