$(document).ready(function () {
  $('.btn-desc').click(function () { 
    $('.pop-up').fadeIn();    
  });
});